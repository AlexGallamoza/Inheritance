
public class Person {
  
  private String firstName;
  private String lastName;
  
  Person(){
    firstName = "";
    lastName = "";
  }
  Person(String iFirst, String iLast){
    firstName = iFirst;
    lastName = iLast;
  }
  
  public String getFirstName(){
    return firstName;
  }
  public String getLastName(){
    return lastName;
  }
  
  public void setName(String iFirst, String iLast){
    firstName = iFirst;
    lastName = iLast;
  }
  
  public void printLastFirst(){
    System.out.print(lastName + "," + firstName);
  }
  public void print(){
    System.out.print(firstName + " " + lastName);
  }
  
  public String toString(){
    return firstName + " " + lastName;
  }
  
  
  
  
  public Person getPerson(Object obj){
    /*if(obj == null) return null;
     if(!(obj instanceof Point)) return null;
     return (Point) obj; */
    
    return (obj == null || !(obj instanceof Person))? null:(Person)obj;
    
  }
  
  public boolean equals(Object obj){    
    Person p2 = getPerson(obj);
    if(obj == null) return false;
    return firstName == p2.firstName && lastName == p2.lastName ;
  }
  
  public void copy(Object obj){
   /*  firstName = p2.firstName;
    lastName = p2.lastName; */
    
    Person p2 = getPerson(obj);
    
  }
  
  public Person getCopy(Object obj){
    /*Person copy = new Person();
    copy.firstName = firstName;
    copy.lastName = lastName;
    return copy;  */
    Person copy = getPerson(obj);
    return copy;
  }
  
  
  
  
  
}
