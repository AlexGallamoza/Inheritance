
public class Employee extends Person{
  private double payRate;
  private double hoursWorked;
  private String department;
  
  public final int HOURS = 40;
  public final double OVERTIME = 1.5;
  
  //default constructor
  public Employee(){
    super();
    payRate = 0;
    hoursWorked = 0;
    department = "";
  }
  public Employee(String iFirst, String iLast, double pay_Rate, double hrs_Worked, String dept){
    super(iFirst, iLast);
    payRate = pay_Rate;
    hoursWorked = hrs_Worked;
    department = dept;
  } 
  
  public Employee getEmployee(Object obj){    
    return (obj == null || !(obj instanceof Employee))? null:(Employee)obj;
  }
  
  
  public String toString(){
    //should return a String like this:
    //The wages for xxxx from the xxxx department are: $xxxxx.xx"
    
    return "The wages for " + super.toString() + " from the " + department + " are: $" + String.format(".2f",calculatePay());
  } 
  
  public void print(){
    //Should print output like this (same line):
    //The employee xxxx from the xxxx department worked xx hours
    //with a pay rate of $xxx.xx. The wages for this employee are $xxxxx.xx
    System.out.println("The employee " + super.toString() + " from the " + department + " deparment worked " + hoursWorked + " hours with a pay rate of $ " + String.format("%.2f", payRate)
    + ". The wages for this employee are $ " + String.format("%.2f", calculatePay()));                     
  }
  
  public double calculatePay(){
    if(hoursWorked <= 40) return hoursWorked * payRate;
    else return (40 * payRate) + ((hoursWorked - 40) * OVERTIME * payRate);
  } 
  
  public void setAll(String first, String last, double rate, double hours, String dep){
    setName(first, last);
    payRate = rate;
    hoursWorked = hours;
    department = dep;
  }
  
  public double getPayRate(){
    return payRate;
  }
  
  public double getHoursWorked(){
    return hoursWorked;
  }
  public String getDepartment(){
    return department;
  }
  
  public boolean equals(Object obj){    
    Employee e2 = getEmployee(obj);
    return (e2!=null) && super.equals(e2) && (payRate == e2.payRate) && (hoursWorked == e2.hoursWorked) && (department == e2.department);
  }
  
  public Employee getCopy(Object obj){
    Employee emp1 = getEmployee(obj);
    return emp1;
    
  } 
  
  
  public void copy(Employee e){    
    super.copy(e);
    payRate = e.payRate;
    hoursWorked = e.hoursWorked;
    department = e.department;
  }
  
  
  
  
  
}
