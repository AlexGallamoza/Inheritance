import java.util.*;
public class Person_Client {
  
  
  public static void main(String[] args) { 
    Scanner input = new Scanner(System.in);
    String last, first, dept;
    double pay_rate;
    int hours;
    Employee prof = new Employee("John", "Doe", 25.50, 50, "COSC");
    Employee newEmp = new Employee();
    
    System.out.print("Enter employee last name: ");
    last = input.next();
    System.out.print("Enter employee first name: ");
    first = input.next();
    
    System.out.print("Enter department: ");
    dept = input.next();
    
    System.out.print("Enter employee pay rate: ");
    pay_rate = input.nextDouble();
    System.out.print("Enter employee hours worked: ");
    hours = input.nextInt();
    
    newEmp.setAll(first,last,pay_rate,hours,dept);
    
    System.out.println("---Record for bothe employees with overrideen .toString from subclass---");
    System.out.println(prof.toString());
    System.out.println(newEmp.toString());
    
    System.out.println("--Output with calls to overridden method to print from subclass---");
    prof.print();
    newEmp.print();
    
    System.out.println("--Output with calls to getters from the superclass---");
    System.out.println("The wages for " + newEmp.getFirstName() + " " + newEmp.getLastName() + " from the " +
                       newEmp.getDepartment() + " department are $" + String.format("%.2f",newEmp.calculatePay()));                   
    
    System.out.println("---Call to overridden equals/subclass for 2 Employee objects---");
    if (prof.equals((Object) newEmp)) {
      System.out.println("Employee with the same record found.");
      
    } else {
      System.out.println("Couldn't find an employee with the same record");
    }
  } 
  
  
  
}
