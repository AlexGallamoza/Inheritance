
public class Inheritance_Exercise_1_Client {
  
  
  public static void main(String[] args) { 
    Class_1 object1 = new Class_1(2, 34);
    Class_2 object2 = new Class_2(7, 0, 42);
    
    System.out.print("The values x and y values of first object are: ");
    object1.print();
    System.out.println();
    System.out.print("The values x, y, and z values of second object are: ");
    object2.print();
    System.out.println();
    
    object1.set(30, 11);
    object2.set(36, 12, 11);
    
    System.out.print("The new values of x and y values of first object are: ");
    object1.print();
    System.out.println();
    System.out.print("The new values of x, y, and z values of second object are: ");
    object2.print();
    System.out.println();
    
    System.out.print("The values x and y values of first object after calling toString are: " + object1.toString());
    System.out.println();
    System.out.print("The values x, y, and z values of second object after calling toString are: " + object2.toString());

    
  }
  
  
  
}
